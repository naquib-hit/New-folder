<template>
  <Nuxt />
</template>

<style>
  body {
    @apply m-0 p-0 overflow-x-hidden text-base;
  }
</style>
