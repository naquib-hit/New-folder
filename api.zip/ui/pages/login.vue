<template>
    <main class="w-screen h-screen px-2 bg-indigo-600 flex flex-col items-center justify-center ">
        <!-- start login-container -->
        <div class="w-full lg:w-3/12 p-6 bg-white rounded shadow">

            <form @submit.prevent="submit" class="w-full h-full flex flex-col">
                <h3 class="underline-offset-8 text-center text-3xl text-gray-600 drop-shadow-md">LOGIN</h3>
                <label class="mt-4">Username</label>
                <input type="text" class="w-full px-3 py-2  rounded border border-gray-300 focus-visible:outline-1 outline-blue-600"
                    v-model.trim="$v.auth.username.$model">
                <!-- Message username -->    
                <small v-if="!$v.auth.username.required && auth.hasError" class="text-red-600">Username harus terisi !!!</small>
                <!-- passwword -->
                <label class="mt-4">Password</label>
                <input type="password" class="w-full px-3 py-2  rounded border border-gray-300 focus-visible:outline-1 outline-blue-600"
                    v-model.trim="$v.auth.password.$model">
                <!-- Message paswor --> 
                <small v-if="!$v.auth.password.required && auth.hasError" class="text-red-600">Password harus terisi !!!</small>
                <span class="mt-6 w-full flex flex-grow-0 justify-end">
                    <button type="submit" class="px-3 py-2 bg-blue-600 active:bg-blue-400 text-white rounded shadow">Login</button>
                </span>
            </form>
           
        </div>
        <!-- end login-container -->
    </main>
</template>

<script>
    import { validationMixin } from 'vuelidate';
    import { required } from 'vuelidate/lib/validators';

    export default {
        name: 'LoginPage',
        mixins: [validationMixin],
        data() {
            return {
                auth: {
                    username: '',
                    password: ''
                },
                hasError: false
            }
        },
        validations: {
           auth: {
               username: {
                   required
               },
               password: {
                   required
               }
           }
        },
        methods: {
            async submit() {
                this.auth.hasError = true;
                // validate
                try {
                    this.$v.$touch()
                    if (this.$v.$invalid) {
                        return false;
                    }

                    // authenticate user
                    const response = await this.$auth.loginWith('local', 
                                                { 
                                                    data: {
                                                        username: this.auth.username,
                                                        password: this.auth.password
                                                    }
                                                });
                    let datas      = await response.json();

                }
                catch(err) {
                    console.log(err);
                }
            }
        }
    }
</script>