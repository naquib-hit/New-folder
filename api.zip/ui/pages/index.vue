<template>
</template>

<script>
export default {
  name: 'IndexPage'
}
</script>
